# TurmaNResponsividade
Repositório criado para hospedar o projeto desenvolvido na segunda jornada do GE de Trilhas de Programação.
